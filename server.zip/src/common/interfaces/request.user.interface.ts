interface RequestUser {
  userId: string;
  email?: string;
  name?: string;
}

export default RequestUser;
