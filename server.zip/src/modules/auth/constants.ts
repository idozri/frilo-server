/** @format */

export const jwtConstants = {
  secret: process.env.JWT_SECRET || 'your-secret-key', // Make sure to use an environment variable in production
};
